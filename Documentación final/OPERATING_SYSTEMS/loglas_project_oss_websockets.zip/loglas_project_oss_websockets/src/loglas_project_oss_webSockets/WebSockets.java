package loglas_project_oss_webSockets;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WebSockets implements Runnable {
    private List<Player> list;

    public WebSockets(List<Player>list) {
        this.list = new ArrayList<Player>(list);
    }

    public void run() {
        Random random = new Random();
        for (int i= 0;;) {
            try {
                Thread.sleep(random.nextInt(10));
            } catch (InterruptedException e) {}
            Player.useWebSockets(list.get(i));
            i = (i+1)%list.size();
        }
    }
}