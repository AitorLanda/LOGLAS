package loglas_project_oss_webSockets;

public class Player {
    private final String name;

    public Player(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
        
    public static synchronized void useWebSockets(Player player) {
    	//WebSocket code will be here
    	System.out.println("WebSockets used by: "+player.getName());
    }
}
