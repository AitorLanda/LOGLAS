package loglas_project_oss_webSockets;

import java.util.ArrayList;
import java.util.List;

public class WebSocketsMain {        

	static List<Player> list;
	
	public WebSocketsMain() {
		
		list = new ArrayList<Player>();
		crearPlayers();
	}
	
    private void crearPlayers() {
    	for(int i=0;i<30;i++)
    		list.add(new Player("Player_"+i));
	}

	public static void main(String[] args) {
		WebSocketsMain main = new WebSocketsMain();
        new Thread(new WebSockets(list)).start();
    }
}