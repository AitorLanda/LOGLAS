package loglas_project_oss_playersPuntuationv2;

public class Viewer extends Thread implements Runnable  {


	static int NUM_VIEWERS=0;
	int id;
	String nombre;
	String apellido;
	volatile boolean fin;
	GameController controler;
	
	public Viewer(String nombre, String apellido, GameController controler) {
		
		this.fin= false;
		
		this.id = NUM_VIEWERS++;
		this.nombre = nombre;
		this.apellido = apellido;
		this.controler = controler;

	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	@Override
	public void run() {
		while (!fin){
			if (!this.isInterrupted()){ 
		 
				try {
					controler.mostrarPuntos(this);
					Thread.sleep(500);
				} catch (InterruptedException e) {
					break;
				}
			}
		}
	}
	public void parar(){
		this.fin=true;
	}
}
