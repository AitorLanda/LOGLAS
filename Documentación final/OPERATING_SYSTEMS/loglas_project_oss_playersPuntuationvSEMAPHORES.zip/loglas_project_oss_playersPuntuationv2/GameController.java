package loglas_project_oss_playersPuntuationv2;

import java.util.HashMap;
import java.util.concurrent.Semaphore;

public class GameController {

	HashMap<Player, Integer> tablaPuntuaciones;
	
	Semaphore writePuntuation;
	Semaphore mutex;
	Semaphore entry;
	
	volatile int numViewers;
	volatile int contPremio;
	
	public GameController(HashMap<Player, Integer> tablaPuntuaciones) {
		
		
		numViewers = 0;
		contPremio=0;
		
		writePuntuation = new Semaphore (1);
		mutex = new Semaphore(1);
		entry = new Semaphore (1);
		
		this.tablaPuntuaciones = tablaPuntuaciones;
	}




	public void anadirPuntos(Player player) throws InterruptedException {
		
		entry.acquire();
		writePuntuation.acquire();
		
		this.contPremio++;
		
		if(this.contPremio==1){
			
		//	this.tablaPuntuaciones.merge(player,50, Integer::sum);
			this.tablaPuntuaciones.computeIfPresent(player, (k, v) -> v + 50);
			((Player) player).anadirPuntos(50);
		}
		
		if(this.contPremio==2) {
			this.tablaPuntuaciones.computeIfPresent(player, (k, v) -> v + 30);
			((Player) player).anadirPuntos(30);
		}
		
		if(this.contPremio==3) {
			this.tablaPuntuaciones.computeIfPresent(player, (k, v) -> v + 10);
			((Player) player).anadirPuntos(10);
		}
		
		if(player.id == 7) {
			contPremio = 0;

		}
		
		
		writePuntuation.release();
		entry.release();
		
	}

	public void mostrarPuntos(Viewer viewer) throws InterruptedException{
		entry.acquire();
		mutex.acquire();
		
		this.numViewers ++;
		
		if (numViewers == 1){
			writePuntuation.acquire();
		}
		mutex.release();
	
		System.out.print("Viewer "+ viewer.getId() + " "  +  viewer.getNombre() + " " + viewer.getApellido() + " "+"\n");
		this.tablaPuntuaciones.forEach((a, l)->{
			System.out.println(a);
			System.out.println(" puntuacion: " + l);
		});
		
		System.out.println();
		mutex.acquire();
		numViewers --;
		if (numViewers==0){
			writePuntuation.release();
		}
		mutex.release();
	}

}
