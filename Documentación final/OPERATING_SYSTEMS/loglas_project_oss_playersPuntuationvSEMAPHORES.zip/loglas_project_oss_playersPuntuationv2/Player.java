package loglas_project_oss_playersPuntuationv2;

import java.util.Random;

public class Player extends Thread implements Runnable {

	static int NUM_PLAYERS=0;
	int id;
	String nombre;
	String apellido;
	int puntos;
	Random random;
	
	GameController controler;
	boolean bol = false;
	
	public Player(String nombre, String apellido, GameController controler) {
		super();
		this.id = NUM_PLAYERS++;
		this.nombre = nombre;
		this.apellido = apellido;
		this.puntos = 0;
		this.controler = controler;
		random = new Random();
	}

	public long getId() {
		return id;
	}

	public void anadirPuntos(int puntos) {
		this.puntos += puntos;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	@Override
	public String toString() {
		return id + " " + nombre + " " + apellido + " " + puntos;
	}


	@Override
	public void run() {
		for(int i=0; i< 3; i++){
			bol = random.nextBoolean();
			try {
				
				if(bol==true) {
					controler.anadirPuntos(this);
					bol=false;
					
				}
				
				//System.out.println(this.toString());
				Thread.sleep(500);
			} catch (InterruptedException e) {
	
			}
		}
	}

	public int getPuntos() {
		return puntos;
	}
}
