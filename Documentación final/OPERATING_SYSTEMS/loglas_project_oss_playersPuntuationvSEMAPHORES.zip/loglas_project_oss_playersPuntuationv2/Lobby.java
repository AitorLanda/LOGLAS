 package loglas_project_oss_playersPuntuationv2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Lobby {

	List<Player> listPlayers;
	List<Viewer> listViewers;

	GameController controler;
	HashMap<Player, Integer> tablaPuntuaciones;
	
	public Lobby() throws InterruptedException {

		this.tablaPuntuaciones = new HashMap<>();
		listPlayers = new ArrayList<>();
		
	
		

		
		controler = new GameController(tablaPuntuaciones);
		
		
		addPlayers();
		
		for(Player player : listPlayers) {
			this.tablaPuntuaciones.put(player, player.getPuntos());
		}
		listViewers = new ArrayList<>();
		addViewer();
		
	}
	
	private void addPlayers() {
		listPlayers.add(new Player("aitor", "landa", controler));
		listPlayers.add(new Player("ane", "sajeras",controler));
		listPlayers.add(new Player("xabi", "landa", controler));
		listPlayers.add(new Player("loredi", "altzibar", controler));
		listPlayers.add(new Player("nahia", "gomara", controler));
		listPlayers.add(new Player("ander", "olaso", controler));
		listPlayers.add(new Player("xabier", "elkorobarrutia", controler));
		
	}

	
	private void addViewer() {
	//	listViewers.add(new Viewer("goiuria", "sagardui", controler));
		listViewers.add(new Viewer("alain", "perez", controler));
		listViewers.add(new Viewer("dani", "reguera",controler));
		listViewers.add(new Viewer("i�igo", "aldalur", controler));
		listViewers.add(new Viewer("oihane", "lameirinhas", controler));
		listViewers.add(new Viewer("josu", "garralda",  controler));
		
	}
	
	public void gameStart() throws InterruptedException {
		
		this.inciarHilos();
		this.esperarHilos();
		
	}

	public void inciarHilos(){
		for(int i=0; i<this.listPlayers.size();i++) {
			Player player = listPlayers.get(i);
			player.start();
		
			
		}
		
		for(int i=0; i<listViewers.size();i++) {
			Viewer viewer = listViewers.get(i);
			viewer.start();
		}
		
	}
	public void esperarHilos() throws InterruptedException{
		for (int i= 0; i<listPlayers.size(); i++){
			Player player = listPlayers.get(i);
		//	player.interrupt();
			player.join();
			
		}
		
		for (int i= 0; i<listViewers.size(); i++){
			Viewer viewer = listViewers.get(i);
			viewer.parar();
			viewer.interrupt();
		//	viewer.run();
			
		}
		
		for (int i= 0; i<listViewers.size(); i++){
			Viewer viewer = listViewers.get(i);
			viewer.join();
			
		}
		
	}

	public static void main (String[] args) throws InterruptedException {
		//RoomView room = new RoomView(loggedUser);
		Lobby lobby = new Lobby();
		lobby.gameStart();
		
	}
}
