package dem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Game {

	List<Player> listPlayers;
	Random random;
	GameController controller;
	
	public Game() throws InterruptedException {
		
		this.controller = new GameController();
		this.listPlayers = new ArrayList<Player>();
		random = new Random();
		
		addPlayers();
		this.startThreads();
		this.waitToFinishThreads();
	}

	public void startThreads(){
		for(int i=0; i<listPlayers.size();i++) {
			Player player = listPlayers.get(i);
			player.start();
		}
	}
	
	private void addPlayers() {
		listPlayers.add(new Player("aitor", "landa", controller ));
		listPlayers.add(new Player("ane", "sajeras", controller));
		listPlayers.add(new Player("xabi", "landa", controller ));
		listPlayers.add(new Player("loredi", "altzibar", controller ));
		listPlayers.add(new Player("nahia", "gomara", controller ));
		listPlayers.add(new Player("ander", "olaso", controller ));
		listPlayers.add(new Player("xabier", "elkorobarrutia", controller));
	}
	
	public void waitToFinishThreads() throws InterruptedException{
		for (int i= 0; i<listPlayers.size(); i++){
			Player player = listPlayers.get(i);
			player.join();
		}
		
	}

	public static void main (String[] args) throws InterruptedException {
		Game startGame = new Game();
	}
	
}
