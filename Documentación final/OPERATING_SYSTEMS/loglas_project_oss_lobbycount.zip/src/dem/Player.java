package dem;

public class Player extends User  {

	static int NUM_PLAYERS=0;
	boolean bol = false;
	
	public Player(String nombre, String apellido, GameController controller) {
		super(nombre, apellido, controller);
		this.id = NUM_PLAYERS++;
		
		this.controller = controller;
	}

	public long getId() {
		return id;
	}



	@Override
	public String toString() {
		return id + " " + firstName + " " + lastName;
	}

	

	@Override
	public void run() {
	
		try {
			controller.entryPlayer(this);
			Thread.sleep(2000);
			controller.exitPlayer(this);
			Thread.sleep(100);
		} catch (InterruptedException e) {
			
		}
	}
}
