package dem;

import java.util.List;

public class GameController {

	List<Player> listPlayers;
	
	int numPlayers;
	
	public GameController() {
		numPlayers=0;
	}

	public GameController(List<Player> listaPlayers) {
		this.listPlayers = listaPlayers;
		numPlayers=0;
	}

	public void entryPlayer(Player player) throws InterruptedException {
		
		synchronized (this) {
			this.numPlayers++;
			System.out.println("Players: "+player.getId()+"---"+this.numPlayers+" entering...");
		}
	}
	
	public void exitPlayer(Player player) {
		synchronized (this) {
			this.numPlayers--;
			System.out.println("Players: "+player.getId()+"---"+this.numPlayers+" existing...");
		}
	}
	
}
